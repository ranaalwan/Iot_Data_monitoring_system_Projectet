rootProject.name = "projekt2_2"
