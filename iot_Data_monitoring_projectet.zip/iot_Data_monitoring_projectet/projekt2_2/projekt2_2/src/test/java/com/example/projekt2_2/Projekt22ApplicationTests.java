package com.example.projekt2_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projekt22ApplicationTests {

    @Test
    void contextLoads() {
    }

}
